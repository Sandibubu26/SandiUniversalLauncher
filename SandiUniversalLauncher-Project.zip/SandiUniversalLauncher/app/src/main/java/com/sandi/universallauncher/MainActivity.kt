package com.sandi.universallauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 13, 20)
    private val panel = Color.rgb(25, 27, 40)
    private val purple = Color.rgb(166, 92, 255)
    private val white = Color.rgb(245, 245, 250)
    private val muted = Color.rgb(170, 174, 195)
    private val games = mutableListOf<GameEntry>()
    private lateinit var gameList: LinearLayout
    private lateinit var emptyText: TextView

    data class GameEntry(val name: String, val uri: Uri, val console: String, val size: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(28))
        }
        scroll.addView(root)

        val brand = text("SANDI  /  GAME TOOLS", 12, purple, true)
        brand.letterSpacing = 0.12f
        root.addView(brand)
        root.addView(space(8))
        root.addView(text("UNIVERSAL\nLAUNCHER", 30, white, true))
        root.addView(space(6))
        root.addView(text("Koleksi game konsolmu, satu tempat.", 14, muted, false))
        root.addView(space(20))

        val hero = card()
        hero.addView(text("▰  YOUR GAME LIBRARY", 12, purple, true))
        hero.addView(space(8))
        hero.addView(text("Import game dari penyimpanan HP, cek formatnya, lalu coba buka dengan emulator yang cocok.", 14, white, false))
        hero.addView(space(14))
        hero.addView(actionButton("＋  IMPORT GAME", true) { chooseGame() })
        root.addView(hero)
        root.addView(space(18))

        root.addView(text("SUPPORTED FILE TYPES", 12, muted, true))
        root.addView(space(8))
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("PS1", "PS2", "PSP", "XBOX*", "NINTENDO*").forEach { label ->
            val chip = TextView(this).apply {
                text = label
                textSize = 11f
                setTextColor(white)
                setPadding(dp(10), dp(8), dp(10), dp(8))
                setBackgroundColor(panel)
            }
            val lp = LinearLayout.LayoutParams(-2, -2)
            lp.marginEnd = dp(7)
            chips.addView(chip, lp)
        }
        root.addView(chips)
        root.addView(space(7))
        root.addView(text("*Dukungan bergantung pada format file dan emulator yang terpasang.", 11, muted, false))
        root.addView(space(22))

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(text("MY GAMES", 13, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(text("LOCAL LIBRARY", 10, purple, true))
        root.addView(row)
        root.addView(space(10))
        emptyText = text("Belum ada game. Tekan IMPORT GAME untuk memilih file.", 14, muted, false).apply {
            setPadding(dp(16), dp(22), dp(16), dp(22))
            gravity = Gravity.CENTER
            setBackgroundColor(panel)
        }
        root.addView(emptyText)
        gameList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(gameList)
        root.addView(space(22))

        val info = card()
        info.addView(text("EMULATOR NOTE", 12, purple, true))
        info.addView(space(6))
        info.addView(text("Aplikasi ini adalah launcher/pengelola koleksi, bukan emulator. Tombol BUKA akan mencoba meneruskan file ke aplikasi lain yang kompatibel. Tidak semua emulator menerima file lewat cara ini.", 13, muted, false))
        root.addView(info)
        root.addView(space(12))
        root.addView(text("SANDI UNIVERSAL LAUNCHER  •  PROTOTYPE 0.1", 10, muted, false).apply { gravity = Gravity.CENTER })
        setContentView(scroll)
    }

    private fun chooseGame() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        try { startActivityForResult(intent, REQUEST_GAME) }
        catch (_: ActivityNotFoundException) { toast("File picker tidak tersedia di perangkat ini.") }
    }

    @Deprecated("Deprecated in Android API; retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_GAME || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        val name = queryName(uri) ?: "Game file"
        val console = detectConsole(name)
        val size = querySize(uri)
        val entry = GameEntry(name, uri, console, size)
        if (games.none { it.uri == uri }) games.add(entry)
        renderGames()
        toast("File ditambahkan ke library")
    }

    private fun renderGames() {
        gameList.removeAllViews()
        emptyText.visibility = if (games.isEmpty()) View.VISIBLE else View.GONE
        games.forEachIndexed { index, game ->
            val item = card()
            val title = text(game.name, 15, white, true)
            item.addView(title)
            item.addView(space(5))
            item.addView(text("${game.console}  •  ${game.size}", 12, muted, false))
            item.addView(space(12))
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            buttons.addView(actionButton("▶  BUKA", true) { launchGame(game) }, LinearLayout.LayoutParams(0, dp(44), 1f))
            val remove = actionButton("HAPUS", false) {
                games.removeAt(index)
                renderGames()
            }
            val removeLp = LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(8) }
            buttons.addView(remove, removeLp)
            item.addView(buttons)
            val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
            gameList.addView(item, lp)
        }
    }

    private fun launchGame(game: GameEntry) {
        val mime = when (game.name.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
            "iso", "bin", "img", "cso", "chd", "rom", "cue", "nsp", "xci" -> "application/octet-stream"
            else -> "*/*"
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(game.uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(Intent.createChooser(intent, "Buka dengan emulator"))
        } catch (_: ActivityNotFoundException) {
            AlertDialog.Builder(this)
                .setTitle("Emulator yang cocok belum ditemukan")
                .setMessage("File tetap tersimpan di library. Pasang emulator yang mendukung konsol dan format ini, lalu coba lagi. Launcher ini belum menyertakan emulator bawaan.")
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun detectConsole(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return when (ext) {
            "cso", "pbp" -> "PSP (perkiraan)"
            "cue", "chd", "bin", "img" -> "PS1 / disc image (perkiraan)"
            "iso" -> "ISO — PS2 / PSP / Xbox / lainnya"
            "nsp", "xci" -> "Nintendo Switch (format file)"
            "3ds", "cia" -> "Nintendo 3DS (format file)"
            "gba", "gbc", "gb" -> "Game Boy / GBA"
            "nes", "sfc", "smc", "n64", "z64" -> "Nintendo klasik"
            "xiso", "xbe" -> "Xbox original (perkiraan)"
            else -> "Konsol belum dikenali"
        }
    }

    private fun queryName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Exception) { null }
    }

    private fun querySize(uri: Uri): String {
        return try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) {
                    val bytes = c.getLong(0)
                    when {
                        bytes >= 1024L * 1024 * 1024 -> String.format(Locale.US, "%.2f GB", bytes / (1024.0 * 1024 * 1024))
                        bytes >= 1024L * 1024 -> String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024))
                        else -> "$bytes bytes"
                    }
                } else "Ukuran tidak diketahui"
            } ?: "Ukuran tidak diketahui"
        } catch (_: Exception) { "Ukuran tidak diketahui" }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundColor(panel)
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setLineSpacing(dp(2).toFloat(), 1f)
    }

    private fun actionButton(label: String, primary: Boolean, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 12f
        isAllCaps = false
        setTextColor(white)
        setBackgroundColor(if (primary) purple else Color.rgb(55, 57, 75))
        setOnClickListener { onClick() }
    }

    private fun space(heightDp: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(heightDp))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    companion object { private const val REQUEST_GAME = 1001 }
}
