plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.sandi.universallauncher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.sandi.universallauncher"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
