# Sandi Universal Launcher (Prototype 0.1)

Android launcher/library prototype with a dark gaming UI and purple accents.

## Included in this prototype
- Import a game file through Android's file picker.
- Display selected files in a local in-memory library.
- Guess a likely console family from the file extension (not definitive identification).
- Try to open the file using another installed app via Android's chooser.
- No game files are copied into the app; the selected URI is retained with read permission when supported.

## Important limitations
- This is a launcher, **not an emulator**. It does not run PS2/Xbox/etc. games by itself.
- Android apps/emulators may not accept game files through a generic `ACTION_VIEW` intent. If they do not, the user must open the file from inside the emulator.
- `.iso` is ambiguous and cannot reliably identify the console by extension alone.
- No BIOS, copyrighted game files, or emulator binaries are included.
- Actual support for each console depends on a compatible emulator, file format, device performance, and emulator licensing.

## Build an APK with GitHub Actions
1. Upload this project folder to a GitHub repository.
2. Open the repository's **Actions** tab and run **Build Android APK** (or push to `main`/`master`).
3. Open the completed workflow run and download the `SandiUniversalLauncher-debug-apk` artifact.
4. Extract the artifact ZIP and install the debug APK on Android. Android may ask permission to install apps from that source.

You can also open the project in Android Studio and run `:app:assembleDebug` with JDK 17 and Android SDK 35 installed.
